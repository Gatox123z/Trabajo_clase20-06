package inacap.webcomponent.prueba9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prueba9Application {

	public static void main(String[] args) {
		SpringApplication.run(Prueba9Application.class, args);
	}
}
